# 📄 Scripts

Contains R scripts for data exploration, segmentation, modeling, and simulations.