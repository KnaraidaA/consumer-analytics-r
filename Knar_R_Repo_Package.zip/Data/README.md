# 📄 Data

Contains raw data files and RData objects used for analysis and modeling.